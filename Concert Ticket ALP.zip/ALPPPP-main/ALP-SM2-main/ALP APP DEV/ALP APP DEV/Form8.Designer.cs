﻿namespace ALP_APP_DEV
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_transaksi = new System.Windows.Forms.ComboBox();
            this.label_total = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelCount = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.labelSelectedDate = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelCategoryName = new System.Windows.Forms.Label();
            this.labelConcertName = new System.Windows.Forms.Label();
            this.label_back = new System.Windows.Forms.Label();
            this.btn_Confirm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboBox_transaksi
            // 
            this.comboBox_transaksi.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBox_transaksi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.comboBox_transaksi.FormattingEnabled = true;
            this.comboBox_transaksi.Location = new System.Drawing.Point(340, 267);
            this.comboBox_transaksi.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_transaksi.Name = "comboBox_transaksi";
            this.comboBox_transaksi.Size = new System.Drawing.Size(92, 21);
            this.comboBox_transaksi.TabIndex = 19;
            // 
            // label_total
            // 
            this.label_total.AutoSize = true;
            this.label_total.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_total.ForeColor = System.Drawing.Color.Tomato;
            this.label_total.Location = new System.Drawing.Point(410, 243);
            this.label_total.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_total.Name = "label_total";
            this.label_total.Size = new System.Drawing.Size(35, 13);
            this.label_total.TabIndex = 18;
            this.label_total.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(338, 243);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Total";
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelCount.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelCount.Location = new System.Drawing.Point(377, 209);
            this.labelCount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(35, 13);
            this.labelCount.TabIndex = 16;
            this.labelCount.Text = "label4";
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.add.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.add.Location = new System.Drawing.Point(422, 207);
            this.add.Margin = new System.Windows.Forms.Padding(2);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(22, 19);
            this.add.TabIndex = 15;
            this.add.Text = "+";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // minus
            // 
            this.minus.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.minus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.minus.Location = new System.Drawing.Point(340, 207);
            this.minus.Margin = new System.Windows.Forms.Padding(2);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(20, 19);
            this.minus.TabIndex = 14;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = false;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // labelSelectedDate
            // 
            this.labelSelectedDate.AutoSize = true;
            this.labelSelectedDate.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelSelectedDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelSelectedDate.Location = new System.Drawing.Point(377, 177);
            this.labelSelectedDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSelectedDate.Name = "labelSelectedDate";
            this.labelSelectedDate.Size = new System.Drawing.Size(35, 13);
            this.labelSelectedDate.TabIndex = 13;
            this.labelSelectedDate.Text = "label4";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelPrice.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelPrice.Location = new System.Drawing.Point(377, 137);
            this.labelPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(35, 13);
            this.labelPrice.TabIndex = 12;
            this.labelPrice.Text = "label3";
            // 
            // labelCategoryName
            // 
            this.labelCategoryName.AutoSize = true;
            this.labelCategoryName.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelCategoryName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelCategoryName.Location = new System.Drawing.Point(377, 99);
            this.labelCategoryName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCategoryName.Name = "labelCategoryName";
            this.labelCategoryName.Size = new System.Drawing.Size(35, 13);
            this.labelCategoryName.TabIndex = 11;
            this.labelCategoryName.Text = "label2";
            // 
            // labelConcertName
            // 
            this.labelConcertName.AutoSize = true;
            this.labelConcertName.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelConcertName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelConcertName.Location = new System.Drawing.Point(377, 56);
            this.labelConcertName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelConcertName.Name = "labelConcertName";
            this.labelConcertName.Size = new System.Drawing.Size(35, 13);
            this.labelConcertName.TabIndex = 10;
            this.labelConcertName.Text = "label1";
            // 
            // label_back
            // 
            this.label_back.AutoSize = true;
            this.label_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_back.ForeColor = System.Drawing.Color.White;
            this.label_back.Location = new System.Drawing.Point(10, 20);
            this.label_back.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_back.Name = "label_back";
            this.label_back.Size = new System.Drawing.Size(37, 37);
            this.label_back.TabIndex = 20;
            this.label_back.Text = "<";
            this.label_back.Click += new System.EventHandler(this.label_back_Click);
            // 
            // btn_Confirm
            // 
            this.btn_Confirm.Location = new System.Drawing.Point(357, 325);
            this.btn_Confirm.Name = "btn_Confirm";
            this.btn_Confirm.Size = new System.Drawing.Size(75, 23);
            this.btn_Confirm.TabIndex = 21;
            this.btn_Confirm.Text = "confirm";
            this.btn_Confirm.UseVisualStyleBackColor = true;
            this.btn_Confirm.Click += new System.EventHandler(this.btn_Confirm_Click);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Confirm);
            this.Controls.Add(this.label_back);
            this.Controls.Add(this.comboBox_transaksi);
            this.Controls.Add(this.label_total);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.add);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.labelSelectedDate);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.labelCategoryName);
            this.Controls.Add(this.labelConcertName);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form8";
            this.Text = "Form8";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_transaksi;
        private System.Windows.Forms.Label label_total;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Label labelSelectedDate;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelCategoryName;
        private System.Windows.Forms.Label labelConcertName;
        private System.Windows.Forms.Label label_back;
        private System.Windows.Forms.Button btn_Confirm;
    }
}