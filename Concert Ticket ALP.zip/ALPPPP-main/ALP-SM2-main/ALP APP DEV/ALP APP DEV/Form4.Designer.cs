﻿namespace ALP_APP_DEV
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_editPassword = new System.Windows.Forms.Label();
            this.label_back = new System.Windows.Forms.Label();
            this.label_nama = new System.Windows.Forms.Label();
            this.label_nik = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_birthdate = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_noTelp = new System.Windows.Forms.Label();
            this.label_email = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(30, 95);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 133);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label_editPassword
            // 
            this.label_editPassword.AutoSize = true;
            this.label_editPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.1F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_editPassword.ForeColor = System.Drawing.Color.White;
            this.label_editPassword.Location = new System.Drawing.Point(278, 450);
            this.label_editPassword.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_editPassword.Name = "label_editPassword";
            this.label_editPassword.Size = new System.Drawing.Size(100, 18);
            this.label_editPassword.TabIndex = 4;
            this.label_editPassword.Text = "edit password";
            this.label_editPassword.Click += new System.EventHandler(this.label_editPassword_Click);
            // 
            // label_back
            // 
            this.label_back.AutoSize = true;
            this.label_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_back.ForeColor = System.Drawing.Color.White;
            this.label_back.Location = new System.Drawing.Point(12, 18);
            this.label_back.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_back.Name = "label_back";
            this.label_back.Size = new System.Drawing.Size(37, 37);
            this.label_back.TabIndex = 5;
            this.label_back.Text = "<";
            this.label_back.Click += new System.EventHandler(this.label_back_Click);
            // 
            // label_nama
            // 
            this.label_nama.AutoSize = true;
            this.label_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nama.ForeColor = System.Drawing.Color.White;
            this.label_nama.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label_nama.Location = new System.Drawing.Point(216, 95);
            this.label_nama.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_nama.Name = "label_nama";
            this.label_nama.Size = new System.Drawing.Size(107, 37);
            this.label_nama.TabIndex = 1;
            this.label_nama.Text = "Name";
            // 
            // label_nik
            // 
            this.label_nik.AutoSize = true;
            this.label_nik.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nik.ForeColor = System.Drawing.Color.White;
            this.label_nik.Location = new System.Drawing.Point(219, 180);
            this.label_nik.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_nik.Name = "label_nik";
            this.label_nik.Size = new System.Drawing.Size(45, 20);
            this.label_nik.TabIndex = 6;
            this.label_nik.Text = "(NIK)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(220, 155);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "NIK";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(220, 212);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Birthdate";
            // 
            // label_birthdate
            // 
            this.label_birthdate.AutoSize = true;
            this.label_birthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_birthdate.ForeColor = System.Drawing.Color.White;
            this.label_birthdate.Location = new System.Drawing.Point(219, 245);
            this.label_birthdate.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_birthdate.Name = "label_birthdate";
            this.label_birthdate.Size = new System.Drawing.Size(84, 20);
            this.label_birthdate.TabIndex = 9;
            this.label_birthdate.Text = "(Birthdate)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(220, 285);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nomer Telpon";
            // 
            // label_noTelp
            // 
            this.label_noTelp.AutoSize = true;
            this.label_noTelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_noTelp.ForeColor = System.Drawing.Color.White;
            this.label_noTelp.Location = new System.Drawing.Point(219, 315);
            this.label_noTelp.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_noTelp.Name = "label_noTelp";
            this.label_noTelp.Size = new System.Drawing.Size(118, 20);
            this.label_noTelp.TabIndex = 11;
            this.label_noTelp.Text = "(Nomer Telpon)";
            // 
            // label_email
            // 
            this.label_email.AutoSize = true;
            this.label_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_email.ForeColor = System.Drawing.Color.White;
            this.label_email.Location = new System.Drawing.Point(219, 374);
            this.label_email.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label_email.Name = "label_email";
            this.label_email.Size = new System.Drawing.Size(58, 20);
            this.label_email.TabIndex = 13;
            this.label_email.Text = "(Email)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(220, 347);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 16);
            this.label8.TabIndex = 12;
            this.label8.Text = "Email";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(644, 477);
            this.Controls.Add(this.label_email);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label_noTelp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label_birthdate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_nik);
            this.Controls.Add(this.label_back);
            this.Controls.Add(this.label_editPassword);
            this.Controls.Add(this.label_nama);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_editPassword;
        private System.Windows.Forms.Label label_back;
        private System.Windows.Forms.Label label_nama;
        private System.Windows.Forms.Label label_nik;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_birthdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_noTelp;
        private System.Windows.Forms.Label label_email;
        private System.Windows.Forms.Label label8;
    }
}